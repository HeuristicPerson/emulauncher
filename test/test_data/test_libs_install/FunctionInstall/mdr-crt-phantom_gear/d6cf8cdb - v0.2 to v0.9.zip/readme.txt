Test patch to convert "Phantom Gear (World) (v0.2) (Demo) (Aftermarket) (Unl)"
into "Phantom Gear (World) (v0.9) (Demo) (Aftermarket) (Unl)".
