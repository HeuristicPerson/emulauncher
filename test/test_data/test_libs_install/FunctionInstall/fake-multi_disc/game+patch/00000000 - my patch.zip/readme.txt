This is a dummy readme.txt for the patch.
